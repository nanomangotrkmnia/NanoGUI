package dev.nanomango.nanoarray;

import net.minecraft.class_2960;
import net.minecraft.class_304;

/**
 * Registers the keybinds of the framework.
 *
 * <p>The key codes are the GLFW key codes, duplicated here so that the code
 * also compiles against Minecraft versions that replaced GLFW with SDL.</p>
 */
public final class NanoArrayKeybinds {

    /** GLFW key code of the right shift key. */
    public static final int GLFW_KEY_RIGHT_SHIFT = 344;

    /** GLFW key code of the left shift key. */
    public static final int GLFW_KEY_LEFT_SHIFT = 340;

    /** GLFW key code of the F3 key, used for the developer overlay. */
    public static final int GLFW_KEY_F3 = 292;

    private static final String CATEGORY = "nanoarray";

    private static class_304 openKey;
    private static class_304 debugKey;
    private static dev.nanomango.gui.input.Keybind openBind;

    private NanoArrayKeybinds() {
    }

    /**
     * Creates the keybinds. Calling this more than once is safe.
     */
    public static synchronized void register() {
        if (openKey != null) {
            return;
        }
        class_304.class_11900.method_74698(class_2960.method_60655(CATEGORY, "general"));
        // The three argument constructor always uses the keyboard input type,
        // which keeps the code working on the Minecraft versions that renamed
        // the constant.
        openKey = new class_304("key.nanoarray.open", GLFW_KEY_RIGHT_SHIFT, class_304.class_11900.field_62556);
        openBind = new dev.nanomango.gui.input.Keybind("Open GUI", "NanoArray", GLFW_KEY_RIGHT_SHIFT);
        debugKey = new class_304("key.nanoarray.debug", GLFW_KEY_F3 + 256, class_304.class_11900.field_62556);
    }

    /**
     * The keybind that opens and closes the GUI.
     */
    public static class_304 openKey() {
        return openKey;
    }

    /**
     * The keybind that toggles the developer overlay.
     */
    public static class_304 debugKey() {
        return debugKey;
    }

    /**
     * Framework side representation of the open keybind.
     */
    public static dev.nanomango.gui.input.Keybind openBind() {
        return openBind;
    }
}
