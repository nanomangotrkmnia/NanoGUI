package dev.nanomango.nanoarray.backend;

import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * Adapts the Minecraft 1.21.x graphics object to {@link NanoArrayGraphics}.
 */
public final class GuiGraphicsAdapter implements NanoArrayGraphics {

    private final class_332 graphics;

    public GuiGraphicsAdapter(class_332 graphics) {
        this.graphics = graphics;
    }

    @Override
    public void fill(int x1, int y1, int x2, int y2, int argb) {
        graphics.method_25294(x1, y1, x2, y2, argb);
    }

    @Override
    public void fillGradient(int x1, int y1, int x2, int y2, int topArgb, int bottomArgb) {
        graphics.method_25296(x1, y1, x2, y2, topArgb, bottomArgb);
    }

    @Override
    public void drawString(class_327 font, String text, int x, int y, int argb) {
        graphics.method_25303(font, text, x, y, argb);
    }

    @Override
    public void blit(class_2960 texture, float u, float v, int x, int y, int width, int height,
                     int textureWidth, int textureHeight, int argb) {
        graphics.method_25291(class_10799.field_56883, texture, x, y, u, v,
                width, height, textureWidth, textureHeight, argb);
    }

    @Override
    public void enableScissor(int x1, int y1, int x2, int y2) {
        graphics.method_44379(x1, y1, x2, y2);
    }

    @Override
    public void disableScissor() {
        graphics.method_44380();
    }
}
