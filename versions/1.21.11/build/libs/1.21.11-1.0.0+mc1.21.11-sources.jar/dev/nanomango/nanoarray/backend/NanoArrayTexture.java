package dev.nanomango.nanoarray.backend;

import net.minecraft.class_2960;

/**
 * A texture that the framework can draw.
 *
 * <p>The framework identifies textures with a small integer id so that the
 * component code stays independent of Minecraft. The host registers the
 * textures it wants to use and resolves the ids again when the draw list is
 * replayed.</p>
 */
public interface NanoArrayTexture {

    /**
     * Identifier of the Minecraft texture.
     */
    class_2960 identifier();

    /**
     * Width of the texture in pixels.
     */
    int width();

    /**
     * Height of the texture in pixels.
     */
    int height();

    /**
     * Aspect ratio of the texture, {@code width / height}.
     */
    default float aspect() {
        int h = height();
        return h <= 0 ? 0.0F : (float) width() / h;
    }
}
