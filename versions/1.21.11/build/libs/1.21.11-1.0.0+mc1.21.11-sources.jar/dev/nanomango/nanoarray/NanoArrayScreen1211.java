package dev.nanomango.nanoarray;

import dev.nanomango.nanoarray.backend.GuiGraphicsAdapter;
import dev.nanomango.nanoarray.backend.NanoArrayGraphics;
import net.minecraft.class_2561;
import net.minecraft.class_332;

/**
 * Screen implementation for Minecraft 1.21.11.
 *
 * <p>1.21.11 still draws the GUI immediately inside {@link #method_25394}.</p>
 */
public final class NanoArrayScreen1211 extends AbstractNanoArrayScreen {

    public NanoArrayScreen1211(NanoArrayCore core) {
        super(core, class_2561.method_43470("NanoArray"));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        renderGui(new GuiGraphicsAdapter(graphics), mouseX, mouseY, partialTick);
    }

    @Override
    protected void renderGui(NanoArrayGraphics graphics, int mouseX, int mouseY, float partialTick) {
        core.render(graphics, field_22789, field_22790, partialTick);
    }
}
