package dev.nanomango.nanoarray.font;

import dev.nanomango.gui.font.Font;
import dev.nanomango.gui.font.TextSink;

/**
 * Font implementation backed by the Minecraft font atlas.
 */
public final class MinecraftFont implements Font {

    private final int id;
    private final String name;
    private final net.minecraft.class_327 minecraftFont;

    public MinecraftFont(int id, String name, net.minecraft.class_327 minecraftFont) {
        this.id = id;
        this.name = name;
        this.minecraftFont = minecraftFont;
    }

    /**
     * The wrapped Minecraft font.
     */
    public net.minecraft.class_327 minecraftFont() {
        return minecraftFont;
    }

    @Override
    public int id() {
        return id;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public float height() {
        return minecraftFont.field_2000;
    }

    @Override
    public float ascent() {
        return minecraftFont.field_2000 * 0.75F;
    }

    @Override
    public float width(String text) {
        if (text == null || text.isEmpty()) {
            return 0.0F;
        }
        return minecraftFont.method_1727(text);
    }

    @Override
    public float width(CharSequence text, int start, int end) {
        if (text == null || start >= end) {
            return 0.0F;
        }
        return minecraftFont.method_1727(text.subSequence(start, end).toString());
    }

    @Override
    public boolean supportsUnicode() {
        return minecraftFont.method_1726() || minecraftFont.method_1727("\u4f60\u597d") > 0;
    }

    @Override
    public void draw(TextSink sink, String text, float x, float y, int argb) {
        if (text == null || text.isEmpty()) {
            return;
        }
        sink.builtin(id, text, x, y, argb);
    }
}
