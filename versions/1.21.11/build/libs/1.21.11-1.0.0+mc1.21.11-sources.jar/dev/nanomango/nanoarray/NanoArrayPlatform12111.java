package dev.nanomango.nanoarray;

import net.minecraft.class_310;
import net.minecraft.class_437;

/**
 * Version specific screen management for Minecraft 1.21.11.
 */
public final class NanoArrayPlatform12111 implements NanoArrayPlatform {

    @Override
    public class_437 createScreen() {
        return new NanoArrayScreen1211(NanoArrayCore.get());
    }

    @Override
    public void openScreen(class_437 screen) {
        class_310.method_1551().method_1507(screen);
    }

    @Override
    public void closeScreen() {
        class_310.method_1551().method_1507(null);
    }

    @Override
    public boolean supportsVectorRendering() {
        return true;
    }
}
