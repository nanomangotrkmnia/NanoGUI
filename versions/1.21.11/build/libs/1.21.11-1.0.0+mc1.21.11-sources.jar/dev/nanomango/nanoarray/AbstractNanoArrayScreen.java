package dev.nanomango.nanoarray;

import dev.nanomango.nanoarray.backend.NanoArrayGraphics;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_437;

/**
 * Base class of the screen that hosts the GUI.
 *
 * <p>The input handling is identical on every supported Minecraft version
 * because 1.21.11 already uses the event based input API.</p>
 */
public abstract class AbstractNanoArrayScreen extends class_437 {

    protected final NanoArrayCore core;

    protected AbstractNanoArrayScreen(NanoArrayCore core, class_2561 title) {
        super(title);
        this.core = core;
    }

    /**
     * Draws the GUI. Implemented by the version specific subclasses because
     * Minecraft 1.21.11 and 26.x use different rendering calls.
     */
    protected abstract void renderGui(NanoArrayGraphics graphics, int mouseX, int mouseY, float partialTick);

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25422() {
        // The GUI is closed through the keybind so that the state stays
        // consistent, but escape still closes the screen.
        return true;
    }

    @Override
    public void method_25419() {
        core.gui().close();
        super.method_25419();
    }

    @Override
    public void method_25432() {
        core.save();
        super.method_25432();
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (core.gui().isOpen()) {
            if (core.gui().keyPressed(event.comp_4795(), event.comp_4797())) {
                return true;
            }
            // Every key press is consumed so that nothing leaks into the
            // game while the GUI is open.
            return true;
        }
        return super.method_25404(event);
    }

    @Override
    public boolean method_16803(class_11908 event) {
        if (core.gui().isOpen()) {
            core.gui().keyReleased(event.comp_4795(), event.comp_4797());
            return true;
        }
        return super.method_16803(event);
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (core.gui().isOpen()) {
            return core.gui().charTyped(event.comp_4793()) || true;
        }
        return super.method_25400(event);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if (core.gui().isOpen()) {
            core.gui().mouseClicked(event.comp_4798(), event.comp_4799(), event.method_74245());
            // Clicks are always consumed so that they cannot reach the world.
            return true;
        }
        return super.method_25402(event, doubleClick);
    }

    @Override
    public boolean method_25406(class_11909 event) {
        if (core.gui().isOpen()) {
            core.gui().mouseReleased(event.comp_4798(), event.comp_4799(), event.method_74245());
            return true;
        }
        return super.method_25406(event);
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        if (core.gui().isOpen()) {
            return core.gui().mouseDragged(event.comp_4798(), event.comp_4799(), event.method_74245(), dragX, dragY) || true;
        }
        return super.method_25403(event, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (core.gui().isOpen()) {
            return core.gui().mouseScrolled(mouseX, mouseY, scrollX, scrollY) || true;
        }
        return super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        if (core.gui().isOpen()) {
            core.mouseMoved(mouseX, mouseY);
        }
        super.method_16014(mouseX, mouseY);
    }
}
