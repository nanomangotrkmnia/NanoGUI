package dev.nanomango.nanoarray.backend;

import dev.nanomango.gui.font.FontTexture;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Uploads the glyph atlases of the rasterising fonts into Minecraft textures.
 *
 * <p>Every atlas is backed by a {@link class_1043} that is registered with
 * the texture manager, so it can be drawn with the regular Minecraft blit
 * calls. The pixels are only copied to the GPU when the atlas changed, which
 * keeps the per frame cost of the text rendering at zero.</p>
 */
public final class FontAtlasRegistry {

    /** Namespace of the generated texture identifiers. */
    public static final String NAMESPACE = "nanoarray";

    private final Map<Integer, Atlas> atlases = new HashMap<>();

    /**
     * Returns the texture of a font, uploading the atlas when it changed.
     *
     * @param fontId  id of the font
     * @param texture the glyph atlas of the font
     * @return the atlas or {@code null} when the font has no atlas
     */
    public Atlas atlas(int fontId, FontTexture texture) {
        if (texture == null) {
            return null;
        }
        int width = texture.width();
        int height = texture.height();
        if (width <= 0 || height <= 0) {
            return null;
        }

        Atlas atlas = atlases.get(fontId);
        if (atlas == null || !atlas.matches(width, height)) {
            atlas = new Atlas(fontId, width, height);
            atlases.put(fontId, atlas);
        }
        atlas.update(texture);
        return atlas;
    }

    /**
     * Releases every texture that was created by this registry.
     */
    public void close() {
        for (Atlas atlas : atlases.values()) {
            atlas.close();
        }
        atlases.clear();
    }

    /**
     * A single glyph atlas that is backed by a Minecraft texture.
     */
    public static final class Atlas {

        private final class_2960 identifier;
        private final class_1043 texture;
        private final class_1011 image;
        private final int[] pixels;
        private int revision = -1;

        Atlas(int fontId, int width, int height) {
            this.identifier = class_2960.method_60655(NAMESPACE, "font/atlas_" + fontId);
            this.texture = new class_1043(() -> "NanoArray Font Atlas", width, height, false);
            class_1011 created = texture.method_4525();
            if (created == null) {
                throw new IllegalStateException("The font atlas texture has no pixel buffer");
            }
            this.image = created;
            this.pixels = new int[width * height];

            class_310.method_1551().method_1531().method_4616(identifier, texture);
        }

        boolean matches(int width, int height) {
            return image.method_4307() == width && image.method_4323() == height;
        }

        /**
         * Copies the atlas into the GPU texture when it changed.
         */
        void update(FontTexture source) {
            int sourceRevision = source.revision();
            if (sourceRevision == revision) {
                return;
            }

            int width = image.method_4307();
            int height = image.method_4323();
            source.writePixels(pixels);

            for (int y = 0; y < height; y++) {
                int row = y * width;
                for (int x = 0; x < width; x++) {
                    image.method_61941(x, y, pixels[row + x]);
                }
            }

            texture.method_4524();
            revision = sourceRevision;
        }

        /**
         * Identifier of the Minecraft texture that holds the atlas.
         */
        public class_2960 identifier() {
            return identifier;
        }

        /**
         * Width of the atlas in pixels.
         */
        public int width() {
            return image.method_4307();
        }

        /**
         * Height of the atlas in pixels.
         */
        public int height() {
            return image.method_4323();
        }

        void close() {
            texture.close();
        }
    }
}
